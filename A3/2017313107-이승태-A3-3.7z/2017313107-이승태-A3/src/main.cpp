#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility
#include "trackball.h"

//*************************************
// global constants
static const char*	window_name = "cgbase - transform - Stanford dragon colored by normals";
static const char*	vert_shader_path = "../bin/shaders/transform.vert";
static const char*	frag_shader_path = "../bin/shaders/transform.frag";
static const char*	mesh_vertex_path = "../bin/mesh/dragon.vertex.bin";
static const char*	mesh_index_path	= "../bin/mesh/dragon.index.bin";
uint				NUM_INSTANCE = 9;	// initial instances
uint				NUM_INSTANCE_satellite = 15;

int gra = 0;
uint NUM_TESS = 40;
uint tri_num = 0;
std::vector<vertex>	unit_sphere_vertices;
bool b_wireframe = false;
bool rotate = true;
float rotate_time = 0.0f;
bool elipse = 0;
float e_rate = 2.0f;
float max_e_rate = 3.0f;
float min_e_rate = 1.0f;
dvec2 pos;
dvec2 later_pos;
bool press = 0;
bool right_press = 0;
bool middle_press = 0;
bool moon = 0;

struct Sphere {
	float rotate_time[8] = { 0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f };
	float rotate[8] = { 0.00142f, 0.00112f, 0.00094f, 0.00075f, 0.0004f, 0.0003f, 0.00024f, 0.00021f };
	float distance[8] = {1.3f, 2.2f, 3.0f, 4.0f, 5.5f, 7.0f, 8.5f, 10.0f};
	float radius[8] = { 0.12f, 0.19f, 0.23f, 0.16f, 0.56f, 0.48f, 0.35f, 0.33f };
	float revolution[8] = { 0.00142f, 0.00112f, 0.00094f, 0.00075f, 0.0004f, 0.0003f, 0.00024f, 0.00021f };
	float revolution_time[8] = { 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f};
	int color[8] = { 0,0,0,0,0,0,0,0 };
}sphere;

struct Satellite {
	int parent[15] = { 2,3,3,4,4,4,5,5,5,6,6,6,7,7,7 };
	float radius[15] = { 0.04f, 0.05f, 0.03f,0.04f, 0.05f, 0.03f,0.04f, 0.05f, 0.03f,0.04f, 0.05f, 0.03f,0.04f, 0.05f, 0.03f };
	float distance[15] = { 0.4f, 0.3f, 0.4f, 0.7f, 0.8f,0.9f,0.7f, 0.8f,0.9f,0.7f, 0.8f,0.9f,0.7f, 0.8f,0.9f };
	float revolution[15] = { 0.001f, 0.001f, 0.0004f,0.001f, 0.00045f, 0.00034f,0.001f, 0.00045f, 0.00034f,0.001f, 0.00045f, 0.00034f,0.001f, 0.00045f, 0.00034f };
	float revolution_time[15] = { 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f };
}satellite;

//*************************************
// window objects
GLFWwindow* window = nullptr;
ivec2		window_size = cg_default_window_size(); // initial window size

//*************************************
// common structures
struct camera
{
	vec3	eye = vec3( 0, 0, 10 );
	vec3	at = vec3( 0, 0, 0 );
	vec3	up = vec3( 0, 1, 0 );
	mat4	view_matrix = mat4::look_at( eye, at, up );
		
	float	fovy = PI/3.0f; // must be in radian
	float	aspect_ratio = window_size.x / float(window_size.y);
	float	dNear = 1.0f;
	float	dFar = 1000.0f;
	mat4	projection_matrix;
};


//*************************************
// OpenGL objects
GLuint	program	= 0;	// ID holder for GPU program
GLuint	vertex_array = 0;	// ID holder for vertex array object

//*************************************
// global variables
int		frame = 0;		// index of rendering frames

//*************************************
// scene objects
camera	cam;
trackball	tb;
bool p_shift;
bool p_ctrl;

//*************************************
void update()
{
	// update projection matrix
	cam.aspect_ratio = window_size.x/float(window_size.y);
	cam.projection_matrix = mat4::perspective(cam.fovy, cam.aspect_ratio, cam.dNear, cam.dFar);

	// update uniform variables in vertex/fragment shaders
	GLint uloc;
	uloc = glGetUniformLocation( program, "view_matrix" );			if(uloc>-1) glUniformMatrix4fv( uloc, 1, GL_TRUE, cam.view_matrix );		// update the view matrix (covered later in viewing lecture)
	uloc = glGetUniformLocation( program, "projection_matrix" );	if(uloc>-1) glUniformMatrix4fv( uloc, 1, GL_TRUE, cam.projection_matrix );	// update the projection matrix (covered later in viewing lecture)
}

inline float randf(float m = 0, float M = 1.0f)
{
	float r = rand() / float(RAND_MAX);
	return r * (M - m) + m;
}

void render()
{
	// clear screen (with background color) and clear depth buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	// notify GL that we use our own program
	glUseProgram( program );
	
	// bind vertex array object
	glBindVertexArray( vertex_array );

	if ((p_shift && press) || right_press)
	{
		dvec2 diff = pos - later_pos;
		pos = later_pos;
		cam.view_matrix *= mat4::scale(vec3(1.0f + float(diff.y) * -0.003f));
	}
	else if ((p_ctrl && press) || middle_press)
	{
		dvec2 diff = pos - later_pos;
		pos = later_pos;

		cam.view_matrix =
			mat4::translate(-float(diff.x) * 0.01f, float(diff.y) * 0.01f, 0) *
			cam.view_matrix;
	}

	if (rotate == 1)
	{
		rotate_time += 0.001f;
		for (int k = 1, kn = int(NUM_INSTANCE); k < kn; k++)
			sphere.rotate_time[k - 1] += sphere.rotate[k - 1];
	}

	// render vertices: trigger shader programs to process vertex data
	for (int k = 0, kn = int(NUM_INSTANCE); k < kn; k++)
	{
		// configure transformation parameters
		float theta1;
		if (k == 0)	theta1 = rotate_time;
		else
		{
			theta1 = sphere.rotate_time[k - 1];
		}

		float loc_theta = randf(0, PI / 2.0f);

		mat4 model_matrix;
		// build the model matrix

		if (k == 0)
		{
			model_matrix = mat4::translate(0.0f, 0.0f, 0.0f) *
				mat4::rotate(vec3(0, 1, 0), theta1);
		}
		else
		{
			if (elipse == 0 || k == 1)
			{
				sphere.revolution_time[k - 1] += sphere.revolution[k - 1];
				model_matrix = mat4::rotate(vec3(0, 1, 0), sphere.revolution_time[k - 1]) *
					mat4::translate(vec3(sphere.distance[k - 1], 0, 0.0f)) *
					mat4::rotate(vec3(0, 1, 0), theta1) *
					mat4::scale(vec3(sphere.radius[k - 1]));
			}
			else {
				float focus = e_rate - 1;
				sphere.revolution_time[k - 1] += sphere.revolution[k - 1]/e_rate;
				model_matrix = mat4::translate(vec3(-focus * sphere.distance[k - 1], 0, 0)) *
					mat4::scale(vec3(e_rate, 1.0f, 1.0f)) *
					mat4::rotate(vec3(0, 1, 0), sphere.revolution_time[k - 1]) *
					mat4::translate(vec3(sphere.distance[k - 1], 0, 0.0f)) *
					
					mat4::rotate(vec3(0, 1, 0), -sphere.revolution_time[k - 1]) *
					mat4::scale(vec3(sphere.radius[k - 1] / e_rate, sphere.radius[k - 1], sphere.radius[k - 1])) *
					mat4::rotate(vec3(0, 1, 0), sphere.revolution_time[k - 1] + theta1);
			}
		}
		// update the uniform model matrix and render
		if (k == 0)
		{
			glUniform1i(glGetUniformLocation(program, "gra"), gra);
		}
		else
		{
			glUniform1i(glGetUniformLocation(program, "gra"), sphere.color[k-1]);
		}
		glUniformMatrix4fv( glGetUniformLocation( program, "model_matrix" ), 1, GL_TRUE, model_matrix );
		glDrawElements( GL_TRIANGLES, tri_num * 3, GL_UNSIGNED_INT, nullptr );
	}

	if (moon)
	{
		for (int k = 0, kn = int(NUM_INSTANCE_satellite); k < kn; k++)
		{
			// configure transformation parameters
			float theta1 = rotate_time;
			float loc_theta = randf(0, PI / 2.0f);

			mat4 model_matrix;
			// build the model matrix
			satellite.revolution_time[k] += satellite.revolution[k];
			// update the uniform model matrix and render
			if (!elipse)
			{
				model_matrix = mat4::rotate(vec3(0, 1, 0), sphere.revolution_time[satellite.parent[k]]) *
					mat4::translate(vec3(sphere.distance[satellite.parent[k]], 0, 0.0f)) *
					mat4::rotate(vec3(0, 1, 0), satellite.revolution_time[k]) *
					mat4::translate(vec3(satellite.distance[k], 0, 0.0f)) *
					mat4::scale(vec3(satellite.radius[k])) *
					mat4::rotate(vec3(0, 1, 0), theta1);
			}
			else
			{
				float focus = e_rate - 1;
				model_matrix =
					mat4::translate(vec3(-focus * sphere.distance[satellite.parent[k]], 0, 0)) *
					mat4::scale(vec3(e_rate, 1.0f, 1.0f)) *

					mat4::rotate(vec3(0, 1, 0), sphere.revolution_time[satellite.parent[k]]) *
					mat4::translate(vec3(sphere.distance[satellite.parent[k]], 0, 0.0f)) *

					mat4::rotate(vec3(0, 1, 0), satellite.revolution_time[k]) *
					mat4::translate(vec3(satellite.distance[k], 0, 0.0f)) *
					mat4::rotate(vec3(0, 1, 0), -sphere.revolution_time[satellite.parent[k]] - satellite.revolution_time[k]) *
					mat4::scale(vec3(satellite.radius[k] / e_rate, satellite.radius[k], satellite.radius[k])) *
					mat4::rotate(vec3(0, 1, 0), sphere.revolution_time[satellite.parent[k]] + satellite.revolution_time[k] + theta1);
			}

			glUniform1i(glGetUniformLocation(program, "gra"), sphere.color[k]);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, tri_num * 3, GL_UNSIGNED_INT, nullptr);
		}
	}

	// swap front and back buffers, and display to screen
	glfwSwapBuffers( window );
}

void reshape( GLFWwindow* window, int width, int height )
{
	// set current viewport in pixels (win_x, win_y, win_width, win_height)
	// viewport: the window area that are affected by rendering 
	window_size = ivec2(width,height);
	glViewport( 0, 0, width, height );
}

void print_help()
{
	printf( "[help]\n" );
	printf( "- press ESC or 'q' to terminate the program\n" );
	printf( "- press F1 or 'h' to see help\n" );
	printf( "- press 'D' to change color\n" );
	printf( "- press 'S' to change the orbit (circle, ellipse)\n");
	printf("- press '+', '-' to change the major orbit");
	printf("- press 'm' to see satellites");
	printf( "\n" );
}

void keyboard( GLFWwindow* window, int key, int scancode, int action, int mods )
{
	if(action==GLFW_PRESS)
	{
		if (key == GLFW_KEY_ESCAPE || key == GLFW_KEY_Q)	glfwSetWindowShouldClose(window, GL_TRUE);
		else if (key == GLFW_KEY_H || key == GLFW_KEY_F1)	print_help();
		else if (key == GLFW_KEY_KP_ADD || (key == GLFW_KEY_EQUAL && (mods & GLFW_MOD_SHIFT))/* + */)
		{
			printf("elipse_rate = %f\r", e_rate);
			if(e_rate < max_e_rate)
			e_rate += 0.1f;
		}
		else if (key == GLFW_KEY_KP_SUBTRACT || key == GLFW_KEY_MINUS)
		{
			printf("elipse_rate = %f\r", e_rate);
			if(e_rate > min_e_rate)
			e_rate -= 0.1f;
		}
		else if (key == GLFW_KEY_R)	rotate = !rotate;
		else if (key == GLFW_KEY_D)
		{
			printf("color change\n");
			gra = (gra + 1) % 3;

			int i;
			for (i = 0; i < 7; i++)
			{
				sphere.color[i] = int(randf(0, 9.0f - 0.001f));
			}
		}
		else if (key == GLFW_KEY_S)
		{
			if (!elipse)	printf("ellipse mode On\n");
			else	printf("ellipse mode Off\n");
			elipse = !elipse;
		}
		else if (key == GLFW_KEY_M)
		{
			if (!moon)	printf("satellites On\n");
			else	printf("satellites Off\n");
			moon = !moon;
		}
		else if (key == GLFW_KEY_LEFT_CONTROL || key == GLFW_KEY_RIGHT_CONTROL)
			p_ctrl = 1;
		else if (key == GLFW_KEY_LEFT_SHIFT || key == GLFW_KEY_RIGHT_SHIFT)
			p_shift = 1;
#ifndef GL_ES_VERSION_2_0
		else if (key == GLFW_KEY_W)
		{
			b_wireframe = !b_wireframe;
			glPolygonMode(GL_FRONT_AND_BACK, b_wireframe ? GL_LINE : GL_FILL);
			printf("> using %s mode\n", b_wireframe ? "wireframe" : "solid");
		}
#endif
	}
	if (action == GLFW_RELEASE)
	{
		if (key == GLFW_KEY_LEFT_CONTROL || key == GLFW_KEY_RIGHT_CONTROL)
			p_ctrl = 0;
		else if (key == GLFW_KEY_LEFT_SHIFT || key == GLFW_KEY_RIGHT_SHIFT)
			p_shift = 0;
	}
}

void mouse(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_RIGHT)
	{
		if (action == GLFW_PRESS)	
		{
			right_press = 1;
			glfwGetCursorPos(window, &pos.x, &pos.y);
		}
		else if (action == GLFW_RELEASE)right_press = 0;
	}
	if (button == GLFW_MOUSE_BUTTON_MIDDLE)
	{
		if (action == GLFW_PRESS)
		{
			middle_press = 1;
			glfwGetCursorPos(window, &pos.x, &pos.y);
		}
		else if (action == GLFW_RELEASE) middle_press = 0;
	}
	if (button == GLFW_MOUSE_BUTTON_LEFT)
	{
		if (action == GLFW_PRESS)
		{
			press = 1;
			glfwGetCursorPos(window, &pos.x, &pos.y);
		}
		else if (action == GLFW_RELEASE)	press = 0;
		vec2 npos = cursor_to_ndc(pos, window_size);
		if (action == GLFW_PRESS)			tb.begin(cam.view_matrix, npos);
		else if (action == GLFW_RELEASE)	tb.end();
	}
}

void motion(GLFWwindow* window, double x, double y)
{
	later_pos.x = x;
	later_pos.y = y;
	if (!right_press && !middle_press && !p_shift && !p_ctrl)
	{
		vec2 npos = cursor_to_ndc(dvec2(x, y), window_size);
		if (!tb.is_tracking()) return;
		cam.view_matrix = tb.update(npos);
	}
}

std::vector<vertex> create_sphere_vertices(uint N)
{
	std::vector<vertex> v;
	for (uint k = 0; k <= N; k++)
	{
		float theta = PI * k / float(N);
		float ct = cos(theta), st = sin(theta);
		for (uint j = 0; j <= 2 * N; j++)
		{
			float py = PI * j / float(N);
			float cp = cos(py), sp = sin(py);
			v.push_back({ vec3(st * sp, ct, st * cp), vec3(st * sp,ct,st * cp) , vec2(py / (2 * PI),1 - theta / PI) });
		}
	}
	return v;
}

void update_vertex_buffer(const std::vector<vertex>& vertices, uint N)
{
	static GLuint vertex_buffer = 0;	// ID holder for vertex buffer
	static GLuint index_buffer = 0;		// ID holder for index buffer

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// check exceptions
	if (vertices.empty()) { printf("[error] vertices is empty.\n"); return; }

	// create buffers
	std::vector<uint> indices;
	tri_num = 0;

	for (uint k = 0; k < N - 1; k++)
	{
		for (uint j = 0; j < 2 * N; j++)
		{
			indices.push_back((k * (2 * N + 1)) + j);
			indices.push_back((k * (2 * N + 1)) + 2 * N + 1 + j);
			indices.push_back((k * (2 * N + 1)) + 2 * N + 2 + j);
			tri_num++;
		}
	}
	for (uint k = 1; k < N; k++)
	{
		for (uint j = 0; j < 2 * N; j++)
		{
			indices.push_back((k * (2 * N + 1)) + j);
			indices.push_back((k * (2 * N + 1)) + 2 * N + 2 + j);
			indices.push_back((k * (2 * N + 1)) + 1 + j);
			tri_num++;
		}
	}

	// generation of vertex buffer: use vertices as it is
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array) glDeleteVertexArrays(1, &vertex_array);
	vertex_array = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array) { printf("%s(): failed to create vertex aray\n", __func__); return; }
}

bool user_init()
{
	int i;
	for(i=0;i<=7;i++)
		sphere.revolution_time[i] = randf(0, PI * 2);

	// log hotkeys
	print_help();

	// init GL states
	glLineWidth(1.0f);
	glClearColor( 39/255.0f, 40/255.0f, 34/255.0f, 1.0f );	// set clear color
	glEnable( GL_CULL_FACE );								// turn on backface culling
	glEnable( GL_DEPTH_TEST );								// turn on depth tests

	// define the position of four corner vertices
	unit_sphere_vertices = std::move(create_sphere_vertices(NUM_TESS));

	// create vertex buffer; called again when index buffering mode is toggled
	update_vertex_buffer(unit_sphere_vertices, NUM_TESS);

	return true;
}

void user_finalize()
{
}

int main( int argc, char* argv[] )
{
	// create window and initialize OpenGL extensions
	if(!(window = cg_create_window( window_name, window_size.x, window_size.y ))){ glfwTerminate(); return 1; }
	if(!cg_init_extensions( window )){ glfwTerminate(); return 1; }	// version and extensions

	// initializations and validations
	if(!(program=cg_create_program( vert_shader_path, frag_shader_path ))){ glfwTerminate(); return 1; }	// create and compile shaders/program
	if(!user_init()){ printf( "Failed to user_init()\n" ); glfwTerminate(); return 1; }					// user initialization

	// register event callbacks
	glfwSetWindowSizeCallback( window, reshape );	// callback for window resizing events
    glfwSetKeyCallback( window, keyboard );			// callback for keyboard events
	glfwSetMouseButtonCallback( window, mouse );	// callback for mouse click inputs
	glfwSetCursorPosCallback( window, motion );		// callback for mouse movement

	// enters rendering/event loop
	for( frame=0; !glfwWindowShouldClose(window); frame++ )
	{
		glfwPollEvents();	// polling and processing of events
		update();			// per-frame update
		render();			// per-frame render
	}

	// normal termination
	user_finalize();
	cg_destroy_window(window);

	return 0;
}
