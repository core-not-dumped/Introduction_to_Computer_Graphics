#include "cgmath.h"			// slee's simple math library
#include "stb_image.h"
#define STB_IMAGE_IMPLEMENTATION
#include "cgut2.h"			// slee's OpenGL utility
#include "trackball.h"
#include "assimp_loader.h"
#include "irrKlang\irrKlang.h"
#include "particle.h"

#pragma comment(lib, "irrKlang.lib")
//*************************************
// global constants
static const char*	window_name = "Slime Tower";
static const char*	vert_shader_path = "../bin/shaders/model.vert";
static const char*	frag_shader_path = "../bin/shaders/model.frag";
static const char* face_obj = "../bin/mesh/head/face.obj";
static const char* body_obj = "../bin/mesh/head/body.obj";
static const char* leg_obj = "../bin/mesh/head/leg.obj";
static const char* stone_obj = "../bin/mesh/head/stone.obj";
static const char* sword_obj = "../bin/mesh/head/sword.obj";
static const char* mesh_stair = "../bin/mesh/head/stair4.obj";
static const char* mesh_potion = "../bin/mesh/head/poti.obj";
static const char* mesh_ex = "../bin/mesh/head/ex.obj";
static const char* wood_obj = "../bin/mesh/head/wood5.obj";

static const char*	mp3_path = "../bin/sounds/MP_The Impossible.mp3";
static const char* mp3_path2 = "../bin/sounds/sword.mp3";

//*************************************
// common structures
static const char* title_path = "../bin/images/title.png";		// RGB image
static const char* fail_path = "../bin/images/fail.png";
static const char* success_path = "../bin/images/success.png";
static const char* comment_path = "../bin/images/comment.png";

//*************************************
// window objects
GLFWwindow*	window = nullptr;
ivec2		window_size = cg_default_window_size(); // initial window size

bool init_text();
void render_text(std::string text, GLint x, GLint y, GLfloat scale, vec4 color, GLfloat dpi_scale = 1.0f);
//*******************************************************************
// irrKlang objects
irrklang::ISoundEngine* engine;
irrklang::ISoundSource* mp3_src = nullptr;
irrklang::ISoundSource* mp3_sword = nullptr;

// texture

// screen
// 0 title 1 fail 2 success, other ingame
int screen = 0;
int screen_tmp = 0;

// color
# define RED 0
# define GREEN 1
# define BLUE 2
# define YELLOW 3
# define CYAN 4
# define SHADOW_COLOR 5
# define WHITE 6

// direction
# define RIGHT 0
# define DOWN 1
# define LEFT 2
# define UP 3
int px[4] = {1,0,-1,0};
int pz[4] = {0,1,0,-1};

bool moving = false;
int moving_dir = 0;
float moving_time = 0.0f;
float turn_time = 0.5f;

bool attacking = false;
int attack_dir = 0;
float attack_time = 0.0f;

int looking_dir = 0;

int turn = 0;
int slime_generate_time = 2;
int potion_generate_time = 30;
int level = 1;

float screen_next_time = -1.0f;

float time_speed = 1.0f;

// object
# define SLIME 1
# define USER 2
# define STAIR 5
# define POTION 6
# define STONE 7

//*************************************
// OpenGL objects
GLuint	program	= 0;	// ID holder for GPU program
GLuint	vertex_array_slime = 0;	// ID holder for vertex array object
GLuint	vertex_array_slime_shadow = 0;
GLuint	vertex_array_map = 0;
GLuint	vertex_array_sqare = 0;
GLuint	vertex_array_title = 0;
GLuint	TITLE = 0;
GLuint	FAIL = 1;
GLuint	SUCCESS = 2;
GLuint COMMENT = 7;

//*************************************
// global variables
int		frame = 0;		// index of rendering frames
bool	show_texcoord = false;

uint NUM_MAP_ROW = 21;
uint NUM_MAP_COL = 13;
uint tri_num_map = 0;
int map_color = 6;
float map_length;
float map_not_using_length;
float map_real_length;
uint map[100][100];

struct User
{
	int pos_x = 1;
	int pos_z = 1;
	int next_x = 1;
	int next_z = 1;

	int slen = 2;
	int range_x[4][15] = {
		// right, down, left, up
		{+1,+2,+3,+1,+1,+2,+2,+3,+3,+0,+0,-1,+4,+4,+4},
		{+0,+0,+0,-1,+1,-1,+1,-1,+1,+1,-1,+0,+0,+1,-1},
		{-1,-2,-3,-1,-1,-2,-2,-3,-3,+0,+0,+1,-4,-4,-4},
		{+0,+0,+0,+1,-1,+1,-1,+1,-1,+1,-1,+0,+0,+1,-1}
	};
	int range_z[4][15] = {
		{+0,+0,+0,-1,+1,-1,+1,-1,+1,+1,-1,+0,+0,+1,-1},
		{+1,+2,+3,+1,+1,+2,+2,+3,+3,+0,+0,-1,+4,+4,+4},
		{+0,+0,+0,+1,-1,+1,-1,+1,-1,+1,-1,+0,+0,+1,-1},
		{-1,-2,-3,-1,-1,-2,-2,-3,-3,+0,+0,+1,-4,-4,-4}
	};

	int point = 0;
	int level = 1;
	int exp = 0;
	int attack = 10;
	int full_hp = 100;
	int hp = 100;
	int potion = 0;
	int need_exp = 10;
	int hp_level = 1;
	int attack_level = 1;
} user;

struct Potion
{
	int pos_x;
	int pos_z;
};
int potion_plus_hp = 30;
struct Stone
{
	int pos_x;
	int pos_z;
};
struct Stair
{
	int pos_x = NUM_MAP_ROW - 3;
	int pos_z = NUM_MAP_COL - 2;
}stair;

struct Tree
{
	int pos_x = -1;
	int pos_z = -1;
};


struct Slime
{
	int level = 1;
	int hp = 15;
	int r_hp = 15;
	int at = 1;
	int attack = 3;
	int next_x = 0, next_z = 0;
	int pos_x = 0, pos_z = 0;
	int color = 0;
	int angry = 0;
	int angrytmp = 0;
};

struct dead_slime
{
	int pos_x = 0;
	int pos_z = 0;
	int color = 0;
};

struct light_t
{
	vec4	position = vec4(1.0f, 1.0f, 1.0f, 0.0f);   // directional light
	vec4	ambient = vec4(0.8f, 0.8f, 0.8f, 1.0f);
	vec4	diffuse = vec4(0.8f, 0.8f, 0.8f, 1.0f);
	vec4	specular = vec4(1.0f, 1.0f, 1.0f, 1.0f);
};
light_t		light;

struct material_t
{
	vec4	ambient = vec4(0.2f, 0.2f, 0.2f, 1.0f);
	vec4	diffuse = vec4(0.8f, 0.8f, 0.8f, 1.0f);
	vec4	specular = vec4(1.0f, 1.0f, 1.0f, 1.0f);
	float	shininess = 1000.0f;
};
material_t	material;


std::vector<Potion> potion;
std::vector<Stone> stone;
std::vector<Tree> tree;

uint NUM_TESS = 10;
int NUM_SLIME_COLOR = 5;
uint tri_num_slime = 0;
uint tri_num_slime_shadow = 0;
std::vector<Slime> slime;
std::vector<dead_slime> dead_slimes;
int slime_shadow_color = 5;
static const uint	MIN_INSTANCE = 0;	// minimum instances
static const uint	MAX_INSTANCE = 60;	// maximum instances

std::vector<vertex>	unit_map_vertices;
std::vector<vertex>	unit_slime_vertices;
std::vector<vertex>	unit_slime_shadow_vertices;
std::vector<vertex> unit_sqare;
std::vector<vertex> unit_title;
std::vector<particle> particles;

bool front;
bool back;
int press = 0;
dvec2 pos;
//*************************************
inline float randf(float m = 0, float M = 1.0f)
{
	float r = rand() / float(RAND_MAX);
	return r * (M - m) + m;
}

struct camera
{
	vec3	eye = vec3(1.1f, 15, 3.3f + 7.5f);
	vec3	at = vec3(1.1f, 0, 3.3f);
	vec3	up = vec3(0, 1, 0);
	mat4	view_matrix = mat4::look_at(eye, at, up);

	float	fovy = PI / 4.0f; // must be in radian
	float	aspect_ratio = window_size.x / float(window_size.y);
	float	dNear = 1.0f;
	float	dFar = 1000.0f;
	mat4	projection_matrix;
};

struct Camera_position
{
	float pos_x = 1.1f, pos_z = 3.3f;
	float next_x = 1.1f, next_z = 3.3f;
} camera_position;

// scene objects
mesh2* faceMesh = nullptr;
mesh2* bodyMesh = nullptr;
mesh2* legMesh = nullptr;
mesh2* stairMesh = nullptr;
mesh2* swordMesh = nullptr;
mesh2* stoneMesh = nullptr;
mesh2* potionMesh = nullptr;
mesh2* exMesh = nullptr;
mesh2* woodMesh = nullptr;
camera		cam;
trackball	tb;

void game_reset(void)
{
	int i, j;
	for (i = 0; i < 100; i++)
	{
		for (j = 0; j < 100; j++)	map[i][j] = 0;
	}
	user.point = 0;
	user.level = 1;
	user.exp = 0;
	user.pos_x = 1;
	user.pos_z = 1;
	user.next_x = 1;
	user.next_z = 1;
	user.attack = 10;
	user.full_hp = 100;
	user.hp = 100;
	user.slen = 2;
	user.need_exp = 10;
	user.hp_level = 1;
	user.attack_level = 1;
	user.potion = 3;
	map[1][1] = 2;
	
	stair.pos_x = NUM_MAP_ROW - 3;
	stair.pos_z = NUM_MAP_COL - 2;
	map[stair.pos_x][stair.pos_z] = 5;
	
	tree.clear();
	for (i = 0; i < 10; i++)
	{
		Tree t;
		t.pos_x = (int)(randf(-8, -1));
		t.pos_z = (int)(randf(0, (float)NUM_MAP_COL));
		tree.push_back(t);

		t.pos_x = (int)(randf((float)NUM_MAP_ROW, (float)NUM_MAP_ROW + 8));
		t.pos_z = (int)(randf(0, (float)NUM_MAP_COL));
		tree.push_back(t);

		t.pos_x = (int)(randf(0, (float)NUM_MAP_ROW));
		t.pos_z = (int)(randf(-8, -1));
		tree.push_back(t);
	}

	Stone S;
	S.pos_x = 6;
	S.pos_z = 4;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	S.pos_x = 17;
	S.pos_z = 10;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	S.pos_x = 12;
	S.pos_z = 7;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	S.pos_x = 3;
	S.pos_z = 11;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	
	slime.clear();
	potion.clear();
	dead_slimes.clear();

	level = 1;

	camera_position.pos_x = 1.1f;
	camera_position.pos_z = 3.3f;
	camera_position.next_x = 1.1f;
	camera_position.next_z = 3.3f;

	cam.eye = vec3(1.1f, 15, 3.3f + 7.5f);
	cam.at = vec3(1.1f, 0, 3.3f);
	cam.view_matrix = mat4::look_at(cam.eye, cam.at, cam.up);
}

void generate_slime(int slime_level)
{
	if (slime.size() >= MAX_INSTANCE) return;
	Slime sp;
	while (1)
	{
		sp.pos_x = NUM_MAP_ROW - 1;
		sp.pos_z = int(randf(0.0f, float(NUM_MAP_COL) - 0.00001f));
		if (!map[sp.pos_x][sp.pos_z])	break;
	}
	map[sp.pos_x][sp.pos_z] = SLIME;
	sp.next_x = sp.pos_x;
	sp.next_z = sp.pos_z;
	sp.hp = slime_level * (slime_level + 1) * 5 / 2 + 10;
	sp.r_hp = slime_level * (slime_level + 1) * 5 / 2 + 10;
	sp.attack = slime_level * 3;
	sp.color = slime_level % NUM_SLIME_COLOR;
	sp.level = slime_level;
	sp.angry = 0;
	sp.angrytmp = 0;
	slime.push_back(sp);
	printf("> slime.size() = % -4d\r", slime.size());
}

void generate_potion(void)
{
	Potion p;
	while (1)
	{
		p.pos_x = int(randf(0.0f, float(NUM_MAP_ROW - 1) - 0.00001f));
		p.pos_z = int(randf(0.0f, float(NUM_MAP_COL) - 0.00001f));
		if (!map[p.pos_x][p.pos_z])	break;
	}
	map[p.pos_x][p.pos_z] = POTION;
	potion.push_back(p);
}

void slime_next_pos(uint i)
{
	int rand_dir, next_slime_x, next_slime_z;
	
	if (slime[i].pos_x == NUM_MAP_ROW - 1)	rand_dir = LEFT;
	else if (slime[i].angry == 1)
	{
		if (slime[i].pos_x > user.next_x)		rand_dir = LEFT;
		else if (slime[i].pos_x < user.next_x)	rand_dir = RIGHT;
		else if (slime[i].pos_z < user.next_z)	rand_dir = DOWN;
		else									rand_dir = UP;
	}
	else									rand_dir = int(randf(0.0f, 4.0f - 0.00001f));

	// slime checking user
	uint j;
	for (j = 0; j < 4; j++)
	{
		next_slime_x = slime[i].pos_x + px[(rand_dir + j) % 4];
		next_slime_z = slime[i].pos_z + pz[(rand_dir + j) % 4];
		if (((uint)(next_slime_x) <= NUM_MAP_ROW - 2) && next_slime_x >= 0)
		{
			if (((uint)(next_slime_z) <= NUM_MAP_COL - 1) && next_slime_z >= 0)
			{
				if (next_slime_x == user.next_x && next_slime_z == user.next_z)	break;
				else if (next_slime_x == user.pos_x && next_slime_z == user.pos_z)	break;
			}
		}
	}
	// user found
	if (j != 4)
	{
		if (map[next_slime_x][next_slime_z] == 0)
		{
			slime[i].next_x = next_slime_x;
			slime[i].next_z = next_slime_z;
		}
		else
		{
			slime[i].next_x = slime[i].pos_x;
			slime[i].next_z = slime[i].pos_z;
			user.hp -= slime[i].attack;
			if (user.hp <= 0)
			{
				screen = 1;
				game_reset();
			}
		}
		if(slime[i].angry == 0) slime[i].angrytmp = 1;
		slime[i].angry = 1;
	}
	//user not found
	else
	{
		uint k;
		for (k = 0; k < 4; k++)
		{
			next_slime_x = slime[i].pos_x + px[(rand_dir + k) % 4];
			next_slime_z = slime[i].pos_z + pz[(rand_dir + k) % 4];
			if (((uint)(next_slime_x) <= NUM_MAP_ROW - 2) && next_slime_x >= 0)
			{
				if (((uint)(next_slime_z) <= NUM_MAP_COL - 1) && next_slime_z >= 0)
				{
					if (map[next_slime_x][next_slime_z] == 0)	break;
				}
			}
		}
		if (k != 4)
		{
			slime[i].next_x = next_slime_x;
			slime[i].next_z = next_slime_z;
		}
		else
		{
			slime[i].next_x = slime[i].pos_x;
			slime[i].next_z = slime[i].pos_z;
		}
	}

	map[slime[i].pos_x][slime[i].pos_z] = 0;
	map[slime[i].next_x][slime[i].next_z] = 1;
}

void next_level(void)
{
	level += 1;
	potion.clear();
	slime.clear();
	tree.clear();

	int i, j;
	for (i = 0; i < 100; i++)
	{
		for (j = 0; j < 100; j++)	map[i][j] = 0;
	}

	for (i = 0; i < 10; i++)
	{
		Tree t;
		t.pos_x = (int)(randf(-8,-1));
		t.pos_z = (int)(randf(0, (float)NUM_MAP_COL));
		tree.push_back(t);

		t.pos_x = (int)(randf((float)NUM_MAP_ROW, (float)NUM_MAP_ROW + 8));
		t.pos_z = (int)(randf(0, (float)NUM_MAP_COL));
		tree.push_back(t);

		t.pos_x = (int)(randf(0, (float)NUM_MAP_ROW));
		t.pos_z = (int)(randf(-8, -1));
		tree.push_back(t);
	}

	map[1][1] = USER;
	map[NUM_MAP_ROW - 3][NUM_MAP_COL - 2] = STAIR;

	user.pos_x = 1;
	user.pos_z = 1;
	user.next_x = 1;
	user.next_z = 1;
	
	Stone S;
	S.pos_x = 6;
	S.pos_z = 4;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	S.pos_x = 17;
	S.pos_z = 10;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	S.pos_x = 12;
	S.pos_z = 7;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	S.pos_x = 3;
	S.pos_z = 11;
	map[S.pos_x][S.pos_z] = STONE;
	map[S.pos_x-1][S.pos_z] = STONE;
	map[S.pos_x][S.pos_z-1] = STONE;
	map[S.pos_x-1][S.pos_z-1] = STONE;
	stone.push_back(S);
	
	camera_position.next_x = user.pos_x * map_length;
	camera_position.next_z = user.pos_z * map_length + 2.2f;
}

void print_map(void)
{
	for (uint i = 0;i<NUM_MAP_COL; i++)
	{
		for (uint j = 0; j < NUM_MAP_ROW; j++)
		{
			printf("%d ", map[j][i]);
		}
		printf("\n");
	}
	printf("\n");
}

//*************************************
void update()
{
	glUseProgram(program);

	if (back)	cam.eye += normalize(cam.eye - cam.at) * 0.001f;
	if (front)	cam.eye -= normalize(cam.eye - cam.at) * 0.001f;
	
	for (int k = 0, kn = int(particles.size()); k < kn; k++) particles[k].update();
	
	if (back || front)	cam.view_matrix = mat4::look_at(cam.eye, cam.at, cam.up);

	cam.aspect_ratio = window_size.x / float(window_size.y);
	cam.projection_matrix = mat4::perspective(cam.fovy, cam.aspect_ratio, cam.dNear, cam.dFar);
	// build the model matrix for oscillating scale

	// update uniform variables in vertex/fragment shaders
	GLint uloc;
	uloc = glGetUniformLocation( program, "view_matrix" );			if(uloc>-1) glUniformMatrix4fv( uloc, 1, GL_TRUE, cam.view_matrix );
	uloc = glGetUniformLocation( program, "projection_matrix" );	if(uloc>-1) glUniformMatrix4fv( uloc, 1, GL_TRUE, cam.projection_matrix );

	glActiveTexture(GL_TEXTURE0);								// select the texture slot to bind
}

void render()
{
	float t = 2.0f * float(glfwGetTime());

	mat4 model_matrix;
	// clear screen (with background color) and clear depth buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	// notify GL that we use our own program
	glUseProgram( program );

	// setup light properties
	glUniform4fv(glGetUniformLocation(program, "light_position"), 1, light.position);
	glUniform4fv(glGetUniformLocation(program, "Ia"), 1, light.ambient);
	glUniform4fv(glGetUniformLocation(program, "Id"), 1, light.diffuse);
	glUniform4fv(glGetUniformLocation(program, "Is"), 1, light.specular);

	// setup material properties
	glUniform4fv(glGetUniformLocation(program, "Ka"), 1, material.ambient);
	glUniform4fv(glGetUniformLocation(program, "Kd"), 1, material.diffuse);
	glUniform4fv(glGetUniformLocation(program, "Ks"), 1, material.specular);
	glUniform1f(glGetUniformLocation(program, "shininess"), material.shininess);


	//**********************************
	// 0: title
	// 1: fail
	// 2: success
	// 3: no shader, no texture
	int mode = 10;

	// ******************* title **************************
	if (screen == 0)
	{
		mode = 0;
		glUniform1i(glGetUniformLocation(program, "mode"), mode);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, TITLE);
		glUniform1i(glGetUniformLocation(program, "TEX0"), 0);

		// bind vertex array object
		glBindVertexArray(vertex_array_title);

		// render quad vertices
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);

		glfwSwapBuffers(window);
	}
	// ******************* help **************************
	else if (screen == 7)
	{
		mode = 0;
		glUniform1i(glGetUniformLocation(program, "mode"), mode);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, COMMENT);
		glUniform1i(glGetUniformLocation(program, "TEX0"), 0);

		// bind vertex array object
		glBindVertexArray(vertex_array_title);

		// render quad vertices
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);

		glfwSwapBuffers(window);
	}
	// ******************* fail **************************
	else if (screen == 1)
	{
		mode = 1;
		glUniform1i(glGetUniformLocation(program, "mode"), mode);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, FAIL);
		glUniform1i(glGetUniformLocation(program, "TEX1"), 1);

		// bind vertex array object
		glBindVertexArray(vertex_array_title);

		// render quad vertices
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);

		glfwSwapBuffers(window);
	}
	// ******************* success **************************
	else if (screen == 2)
	{
		camera_position.pos_x = map_length;
		camera_position.pos_z = map_length * 3.0f;

		cam.eye.x = camera_position.pos_x;
		cam.eye.z = camera_position.pos_z + 7.5f;
		cam.at.x = camera_position.pos_x;
		cam.at.z = camera_position.pos_z;
		cam.view_matrix = mat4::look_at(cam.eye, cam.at, cam.up);

		mode = 2;
		glUniform1i(glGetUniformLocation(program, "mode"), mode);
		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, SUCCESS);
		glUniform1i(glGetUniformLocation(program, "TEX2"), 2);

		// bind vertex array object
		glBindVertexArray(vertex_array_title);

		// render quad vertices
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);

		glfwSwapBuffers(window);
	}
	// ******************* in game **************************
	else
	{
		if (moving == 1 && float(glfwGetTime()) > turn_time + moving_time)
		{
			moving = 0;

			user.pos_x = user.next_x;
			user.pos_z = user.next_z;

			for (uint i = 0; i < slime.size(); i++)
			{
				slime[i].pos_x = slime[i].next_x;
				slime[i].pos_z = slime[i].next_z;
			}
			camera_position.pos_x = camera_position.next_x;
			camera_position.pos_z = camera_position.next_z;
		}
		if (attacking && (float(glfwGetTime()) > (turn_time * 2 + attack_time)))
		{
			attacking = 0;

			user.pos_x = user.next_x;
			user.pos_z = user.next_z;

			for (uint i = 0; i < slime.size(); i++)
			{
				slime[i].pos_x = slime[i].next_x;
				slime[i].pos_z = slime[i].next_z;
			}
			camera_position.pos_x = camera_position.next_x;
			camera_position.pos_z = camera_position.next_z;
			
			dead_slimes.clear();
		}
		if (moving)
		{
			looking_dir = moving_dir;

			float real_moving_time = float(glfwGetTime()) - moving_time;
			float ratio = (turn_time - real_moving_time) / turn_time;
			float eye_x = camera_position.pos_x * ratio + camera_position.next_x * (1 - ratio);
			float eye_z = camera_position.pos_z * ratio + camera_position.next_z * (1 - ratio);
			cam.eye.x = eye_x;
			cam.eye.z = eye_z + 7.5f;
			cam.at.x = eye_x;
			cam.at.z = eye_z;
			cam.view_matrix = mat4::look_at(cam.eye, cam.at, cam.up);
		}
		if (attacking)
		{
			looking_dir = attack_dir;
		}
		// **********************render user**********************
		mode = 10;
		glBindVertexArray(faceMesh->vertex_array);
		for (size_t k = 0, kn = faceMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = faceMesh->geometry_list[k];

			float real_position_x, real_position_z;
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (user.pos_x * ratio + user.next_x * (1 - ratio)) + 0.1f;
				real_position_z = map_length * (user.pos_z * ratio + user.next_z * (1 - ratio)) + 0.3f;
			}
			else
			{
				real_position_x = map_length * user.pos_x + 0.1f;
				real_position_z = map_length * user.pos_z + 0.3f;
			}

			if (g.mat->textures.diffuse) {
				glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
				glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
				glUniform1i(glGetUniformLocation(program, "use_texture"), true);
			}
			else {
				glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
				glUniform1i(glGetUniformLocation(program, "use_texture"), false);
			}
			// render vertices: trigger shader programs to process vertex data
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, faceMesh->index_buffer);
			model_matrix = mat4::translate(real_position_x+0.4f, 0.0f, real_position_z+0.4f) *
				mat4::scale(1.5f, 1.5f, 1.5f) *
				mat4::rotate(vec3(0.0f, -1.0f, 0.0f), (PI / 2) * looking_dir);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
		}
		glBindVertexArray(bodyMesh->vertex_array);
		for (size_t k = 0, kn = bodyMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = bodyMesh->geometry_list[k];

			float real_position_x, real_position_z;
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (user.pos_x * ratio + user.next_x * (1 - ratio)) + 0.1f;
				real_position_z = map_length * (user.pos_z * ratio + user.next_z * (1 - ratio)) + 0.3f;
			}
			else
			{
				real_position_x = map_length * user.pos_x + 0.1f;
				real_position_z = map_length * user.pos_z + 0.3f;
			}

			if (g.mat->textures.diffuse) {
				glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
				glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
				glUniform1i(glGetUniformLocation(program, "use_texture"), true);
			}
			else {
				glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
				glUniform1i(glGetUniformLocation(program, "use_texture"), false);
			}
			// render vertices: trigger shader programs to process vertex data
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bodyMesh->index_buffer);
			model_matrix = mat4::translate(real_position_x+0.4f, 0.0f, real_position_z+0.4f) *
				mat4::scale(1.5f, 1.5f, 1.5f) *
				mat4::rotate(vec3(0.0f, -1.0f, 0.0f), (PI / 2) * looking_dir);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
		}
		glBindVertexArray(legMesh->vertex_array);
		for (size_t k = 0, kn = legMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = legMesh->geometry_list[k];

			float real_position_x, real_position_z;
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (user.pos_x * ratio + user.next_x * (1 - ratio)) + 0.1f;
				real_position_z = map_length * (user.pos_z * ratio + user.next_z * (1 - ratio)) + 0.3f;
			}
			else
			{
				real_position_x = map_length * user.pos_x + 0.1f;
				real_position_z = map_length * user.pos_z + 0.3f;
			}

			if (g.mat->textures.diffuse) {
				glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
				glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
				glUniform1i(glGetUniformLocation(program, "use_texture"), true);
			}
			else {
				glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
				glUniform1i(glGetUniformLocation(program, "use_texture"), false);
			}
			// render vertices: trigger shader programs to process vertex data
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, legMesh->index_buffer);
			model_matrix = mat4::translate(real_position_x+0.4f, 0.0f, real_position_z+0.4f) *
				mat4::scale(1.5f, 1.5f, 1.5f) *
				mat4::rotate(vec3(0.0f, -1.0f, 0.0f), (PI / 2) * looking_dir);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
		}
		glBindVertexArray(swordMesh->vertex_array);
		for (size_t k = 0, kn = swordMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = swordMesh->geometry_list[k];

			float real_position_x, real_position_z;
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (user.pos_x * ratio + user.next_x * (1 - ratio)) + 0.1f;
				real_position_z = map_length * (user.pos_z * ratio + user.next_z * (1 - ratio)) + 0.3f;
			}
			else
			{
				real_position_x = map_length * user.pos_x + 0.1f;
				real_position_z = map_length * user.pos_z + 0.3f;
			}

			if (g.mat->textures.diffuse) {
				glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
				glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
				glUniform1i(glGetUniformLocation(program, "use_texture"), true);
			}
			else {
				glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
				glUniform1i(glGetUniformLocation(program, "use_texture"), false);
			}
			// render vertices: trigger shader programs to process vertex data
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, swordMesh->index_buffer);
			model_matrix = mat4::translate(real_position_x+0.4f, 0.0f, real_position_z+0.4f) *
				mat4::scale(1.5f, 1.5f, 1.5f) *
				mat4::rotate(vec3(0.0f, 1.0f, 0.0f), sin(t) / 2 + PI / 2) *
				mat4::rotate(vec3(0.0f, -1.0f, 0.0f), (PI / 2) * looking_dir);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
		}
		mode = 10;
		glBindVertexArray(vertex_array_slime_shadow);
		for (size_t k = 0, kn = 2; k < kn; k++)
		{
			float mul = 2.0f;
			mat4 model_matrix;
			// build the model matrix
			float real_position_x, real_position_z;
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (user.pos_x * ratio + user.next_x * (1 - ratio)) + 0.1f;
				real_position_z = map_length * (user.pos_z * ratio + user.next_z * (1 - ratio)) + 0.3f;
			}
			else
			{
				real_position_x = map_length * user.pos_x + 0.1f;
				real_position_z = map_length * user.pos_z + 0.3f;
			}
			model_matrix = mat4::translate(real_position_x + 0.3f, 0.0f, real_position_z + 0.2f) *
				mat4::rotate(vec3(0, 1, 0), (PI / 2) * (int)(std::pow((-1),k))) *
				mat4::scale(0.8f, 1.0f, 1.0f);

			// update the uniform model matrix and render
			glUniform1i(glGetUniformLocation(program, "mode"), mode);
			glUniform1i(glGetUniformLocation(program, "color"), slime_shadow_color);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, tri_num_slime_shadow * 3, GL_UNSIGNED_INT, nullptr);
		}
		// ********************* render stair **************************
		glBindVertexArray(stairMesh->vertex_array);
		for (size_t k = 0, kn = stairMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = stairMesh->geometry_list[k];

			float real_position_x = map_length * stair.pos_x + 0.5f;
			float real_position_z = map_length * stair.pos_z + 0.2f;
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			if (g.mat->textures.diffuse) {
				glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
				glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
				glUniform1i(glGetUniformLocation(program, "use_texture"), true);
			}
			else {
				glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
				glUniform1i(glGetUniformLocation(program, "use_texture"), false);
			}
			//glUniform1i(glGetUniformLocation(program, "mode"), mode);
			//glUniform1i(glGetUniformLocation(program, "color"), 5);
			// render vertices: trigger shader programs to process vertex data
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, stairMesh->index_buffer);
			model_matrix = mat4::translate(real_position_x, 0.0f, real_position_z) *
				mat4::scale(0.5f, 0.5f, 0.5f) *
				mat4::rotate(vec3(1.0f, 1.0f, 1.0f), PI / 200);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
		}

		//********************** render_slime **********************
		mode = 10;
		glBindVertexArray(vertex_array_slime);
		// render vertices: trigger shader programs to process vertex data
		for (int k = 0, kn = int(slime.size()); k < kn; k++)
		{
			// configure transformation parameters
			float mul = 2.0f;
			// build the model matrix
			
			float real_position_x, real_position_z;
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (slime[k].pos_x * ratio + slime[k].next_x * (1 - ratio)) + map_real_length / 2.0f;
				real_position_z = map_length * (slime[k].pos_z * ratio + slime[k].next_z * (1 - ratio)) + map_real_length / 2.0f;
			}
			else if (attacking && (attack_time + turn_time < float(glfwGetTime())))
			{
				float real_moving_time = float(glfwGetTime()) - attack_time - turn_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (slime[k].pos_x * ratio + slime[k].next_x * (1 - ratio)) + map_real_length / 2.0f;
				real_position_z = map_length * (slime[k].pos_z * ratio + slime[k].next_z * (1 - ratio)) + map_real_length / 2.0f;
			}
			else
			{
				real_position_x = map_length * slime[k].pos_x + map_real_length / 2.0f;
				real_position_z = map_length * slime[k].pos_z + map_real_length / 2.0f;
			}

			model_matrix = mat4::translate(real_position_x, 0.0f, real_position_z) *
				mat4::scale(sin(t) * 0.1f + 1.0f, -sin(t) * 0.4f + 1.0f, sin(t) * 0.1f + 1.0f);

			// update the uniform model matrix and render
			glUniform1i(glGetUniformLocation(program, "mode"), mode);
			glUniform1i(glGetUniformLocation(program, "color"), slime[k].color);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, tri_num_slime * 3, GL_UNSIGNED_INT, nullptr);
			kn = int(slime.size());
		}

		//********************** render slime shadow **********************
		mode = 10;
		glBindVertexArray(vertex_array_slime_shadow);
		for (int k = 0, kn = int(slime.size()); k < kn; k++)
		{
			// configure transformation parameters
			float mul = 2.0f;
			mat4 model_matrix;
			// build the model matrix
			float real_position_x, real_position_z;
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (slime[k].pos_x * ratio + slime[k].next_x * (1 - ratio)) + map_real_length / 2.0f;
				real_position_z = map_length * (slime[k].pos_z * ratio + slime[k].next_z * (1 - ratio)) + map_real_length / 2.0f;
			}
			else if (attacking && (attack_time + turn_time < float(glfwGetTime())))
			{
				float real_moving_time = float(glfwGetTime()) - attack_time - turn_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (slime[k].pos_x * ratio + slime[k].next_x * (1 - ratio)) + map_real_length / 2.0f;
				real_position_z = map_length * (slime[k].pos_z * ratio + slime[k].next_z * (1 - ratio)) + map_real_length / 2.0f;
			}
			else
			{
				real_position_x = map_length * slime[k].pos_x + map_real_length / 2.0f;
				real_position_z = map_length * slime[k].pos_z + map_real_length / 2.0f;
			}

			model_matrix = mat4::translate(real_position_x, 0.0f, real_position_z) *
				mat4::rotate(vec3(0, 1, 0), 7 * PI / 4) *
				mat4::scale(-sin(t) * 0.1f + 1.0f, 1.0f, sin(t) * 0.1f + 1.0f);

			// update the uniform model matrix and render
			glUniform1i(glGetUniformLocation(program, "mode"), mode);
			glUniform1i(glGetUniformLocation(program, "color"), slime_shadow_color);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, tri_num_slime_shadow * 3, GL_UNSIGNED_INT, nullptr);
			kn = int(slime.size());
		}

		// ********************** render slime hp bar **********************
		mode = 3;
		glBindVertexArray(vertex_array_sqare);
		for (int k = 0, kn = int(slime.size()); k < kn; k++)
		{
			float real_position_x, real_position_z;
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (slime[k].pos_x * ratio + slime[k].next_x * (1 - ratio));
				real_position_z = map_length * (slime[k].pos_z * ratio + slime[k].next_z * (1 - ratio)) - map_not_using_length;
			}
			else if (attacking && (attack_time + turn_time < float(glfwGetTime())))
			{
				float real_moving_time = float(glfwGetTime()) - attack_time - turn_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (slime[k].pos_x * ratio + slime[k].next_x * (1 - ratio));
				real_position_z = map_length * (slime[k].pos_z * ratio + slime[k].next_z * (1 - ratio)) - map_not_using_length;
			}
			else
			{
				real_position_x = map_length * slime[k].pos_x;
				real_position_z = map_length * slime[k].pos_z - map_not_using_length;
			}
			model_matrix =
				mat4::translate(real_position_x, 0.01f, real_position_z + map_length) *
				mat4::scale(slime[k].hp / (float)(slime[k].r_hp), 1.0f, map_not_using_length*1.3f);

			glUniform1i(glGetUniformLocation(program, "mode"), mode);
			glUniform1i(glGetUniformLocation(program, "color"), RED);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
			kn = int(slime.size());
		}

		// ********************** render user hp_bar ********************************
		mode = 3;
		glBindVertexArray(vertex_array_sqare);
		for (int k = 0, kn = 1; k < kn; k++)
		{
			float real_position_x, real_position_z;
			if (moving)
			{
				float real_moving_time = float(glfwGetTime()) - moving_time;
				float ratio = (turn_time - real_moving_time) / turn_time;
				real_position_x = map_length * (user.pos_x * ratio + user.next_x * (1 - ratio));
				real_position_z = map_length * (user.pos_z * ratio + user.next_z * (1 - ratio)) - map_not_using_length;
			}
			else
			{
				real_position_x = map_length * user.pos_x;
				real_position_z = map_length * user.pos_z - map_not_using_length;
			}
			model_matrix =
				mat4::translate(real_position_x, 0.01f, real_position_z + map_length) *
				mat4::scale(user.hp / (float)(user.full_hp), 1.0f, map_not_using_length * 1.3f);

			glUniform1i(glGetUniformLocation(program, "mode"), mode);
			glUniform1i(glGetUniformLocation(program, "color"), RED);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
		}

		//********************** attack range render **********************
		mode = 10;
		if (attacking && (float(glfwGetTime()) < (turn_time + attack_time)))
		{
			//engine->play2D( mp3_sword, true );
			glBindVertexArray(vertex_array_sqare);
			for (int k = 0, kn = int(user.slen); k < kn; k++)
			{
				int real_position_x = user.pos_x + user.range_x[attack_dir][k];
				int real_position_z = user.pos_z + user.range_z[attack_dir][k];

				if (real_position_x >= int(NUM_MAP_ROW) || real_position_x < 0)	continue;
				if (real_position_z >= int(NUM_MAP_COL) || real_position_z < 0)	continue;
				model_matrix =
					mat4::translate(real_position_x * map_length, 0.01f, real_position_z * map_length);

				glUniform1i(glGetUniformLocation(program, "mode"), mode);
				glUniform1i(glGetUniformLocation(program, "color"), RED);
				glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
			}
		}
		//else engine->play2D( mp3_sword, false );

		//********************** potion render **********************
		mode = 10;
		for (int k = 0, kn = int(potion.size()); k < kn; k++)
		{
			glBindVertexArray(vertex_array_sqare);
			
			float real_position_x = potion[k].pos_x * map_length;
			float real_position_z = potion[k].pos_z * map_length;

			model_matrix =
				mat4::translate(real_position_x, 0.01f, real_position_z);

			glUniform1i(glGetUniformLocation(program, "mode"), mode);
			glUniform1i(glGetUniformLocation(program, "color"), BLUE);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
			
		}
		mode = 10;
		glBindVertexArray(stoneMesh->vertex_array);
		for (size_t k = 0, kn = stoneMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = stoneMesh->geometry_list[k];

			
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			for (int l = 0, ln = int(stone.size()); l < ln; l++){
				float real_position_x = stone[l].pos_x * map_length;
				float real_position_z = stone[l].pos_z * map_length;

				if (g.mat->textures.diffuse) {
					glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
					glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
					glUniform1i(glGetUniformLocation(program, "use_texture"), true);
				}
				else {
					glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
					glUniform1i(glGetUniformLocation(program, "use_texture"), false);
				}
				// render vertices: trigger shader programs to process vertex data
				glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, stoneMesh->index_buffer);
				model_matrix = mat4::translate(real_position_x, 0.0f, real_position_z);
				glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
				glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
			}
		}
		mode = 10;
		glBindVertexArray(potionMesh->vertex_array);
		for (size_t k = 0, kn = potionMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = potionMesh->geometry_list[k];

			
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			for (int l = 0, ln = int(potion.size()); l < ln; l++){
				float real_position_x = potion[l].pos_x * map_length + 0.3f;
				float real_position_z = potion[l].pos_z * map_length + 0.3f;

				if (g.mat->textures.diffuse) {
					glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
					glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
					glUniform1i(glGetUniformLocation(program, "use_texture"), true);
				}
				else {
					glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
					glUniform1i(glGetUniformLocation(program, "use_texture"), false);
				}
				// render vertices: trigger shader programs to process vertex data
				glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, potionMesh->index_buffer);
				model_matrix = mat4::translate(real_position_x, 0.0f, real_position_z) *
								mat4::rotate(vec3(0.0f, 1.0f, 0.0f), sin(t) / 2);
				glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
				glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
			}
		}
		// ***************************** ! rendering ************************
		mode = 10;
		glBindVertexArray(exMesh->vertex_array);
		for (size_t k = 0, kn = exMesh->geometry_list.size(); k < kn; k++) {
			geometry& g = exMesh->geometry_list[k];

			
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			for (int l = 0, ln = int(slime.size()); l < ln; l++){
				if (slime[l].angry > 0){
					
				// configure transformation parameters
				float mul = 2.0f;
				// build the model matrix
			
				float real_position_x, real_position_z;
				if (moving)
				{
					float real_moving_time = float(glfwGetTime()) - moving_time;
					float ratio = (turn_time - real_moving_time) / turn_time;
					real_position_x = map_length * (slime[l].pos_x * ratio + slime[l].next_x * (1 - ratio)) + map_real_length / 2.0f;
					real_position_z = map_length * (slime[l].pos_z * ratio + slime[l].next_z * (1 - ratio)) + map_real_length / 2.0f;
				}
				else if (attacking && (attack_time + turn_time < float(glfwGetTime())))
				{
					float real_moving_time = float(glfwGetTime()) - attack_time - turn_time;
					float ratio = (turn_time - real_moving_time) / turn_time;
					real_position_x = map_length * (slime[l].pos_x * ratio + slime[l].next_x * (1 - ratio)) + map_real_length / 2.0f;
					real_position_z = map_length * (slime[l].pos_z * ratio + slime[l].next_z * (1 - ratio)) + map_real_length / 2.0f;
				}
				else
				{
					real_position_x = map_length * slime[l].pos_x + map_real_length / 2.0f;
					real_position_z = map_length * slime[l].pos_z + map_real_length / 2.0f;
				}
				glUniform1i(glGetUniformLocation(program, "mode"), mode);
				glUniform1i(glGetUniformLocation(program, "color"), RED);
				// render vertices: trigger shader programs to process vertex data
				glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, exMesh->index_buffer);
				model_matrix = mat4::translate(real_position_x, 0.2f, real_position_z) * 
								mat4::scale(1.5f, 1.0f, 1.5f) * 
								mat4::rotate(vec3(0.0f, 1.0f, 0.0f), PI / 4);
				glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
				glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
				ln = int(slime.size());
				}
			}
		}

		//********************************* particle rendering *******************
		mode = 10;
		glBindVertexArray(vertex_array_slime);
		if (attacking && (float(glfwGetTime()) < (turn_time + attack_time))) {
			for (uint l = 0, ln = int(particles.size()); l < ln; l++) {
				for (int k = 0, kn = int(dead_slimes.size()); k < kn; k++) {
					float real_position_x = map_length * dead_slimes[k].pos_x + map_real_length / 2.0f - 0.5f;
					float real_position_z = map_length * dead_slimes[k].pos_z + map_real_length / 2.0f - 0.5f;
					mat4 translate_matrix = mat4::translate(vec3(particles[l].pos.x, particles[l].pos.y, particles[l].pos.z));
					mat4 scale_matrix = mat4::scale(particles[l].scale);
					mat4 model_matrix = mat4::translate(vec3(real_position_x, 0.0f, real_position_z)) * translate_matrix * scale_matrix;

					glUniform1i(glGetUniformLocation(program, "mode"), mode);
					glUniform1i(glGetUniformLocation(program, "color"), dead_slimes[k].color);
					glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);

					glDrawElements(GL_TRIANGLES, tri_num_slime * 3, GL_UNSIGNED_INT, nullptr);
				}
			}
		}
		// ********************** wood ***********************************
		glBindVertexArray(woodMesh->vertex_array);
		for (size_t k = 0, kn = tree.size(); k < kn; k++) {
			geometry& g = woodMesh->geometry_list[0];

			float real_position_x, real_position_z;
			glUniform1i(glGetUniformLocation(program, "mode"), 4);
			// 0.1, 0.3 -> to center offset
			real_position_x = map_length * tree[k].pos_x + 0.5f;
			real_position_z = map_length * tree[k].pos_z + 0.7f;
			

			if (g.mat->textures.diffuse) {
				glBindTexture(GL_TEXTURE_2D, g.mat->textures.diffuse->id);
				glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
				glUniform1i(glGetUniformLocation(program, "use_texture"), true);
			}
			else {
				glUniform4fv(glGetUniformLocation(program, "diffuse"), 1, (const float*)(&g.mat->diffuse));
				glUniform1i(glGetUniformLocation(program, "use_texture"), false);
			}
			// render vertices: trigger shader programs to process vertex data
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, woodMesh->index_buffer);
			model_matrix = mat4::translate(real_position_x, 0.0f, real_position_z) *
				mat4::scale(0.7f, 1.0f, 0.7f) *
				mat4::rotate(vec3(0.0f, -1.0f, 0.0f), PI / 2);
			glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
			glDrawElements(GL_TRIANGLES, g.index_count, GL_UNSIGNED_INT, (GLvoid*)(g.index_start * sizeof(GLuint)));
		}

		//********************** map generate **********************
		mode = 10;
		glBindVertexArray(vertex_array_map);
		model_matrix = mat4::translate(0.0f, 0.0f, 0.0f);

		glUniform1i(glGetUniformLocation(program, "mode"), mode);
		glUniform1i(glGetUniformLocation(program, "color"), map_color);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
		glDrawElements(GL_TRIANGLES, tri_num_map * 3, GL_UNSIGNED_INT, nullptr);

		//********************** slime generate line **********************
		mode = 3;
		glBindVertexArray(vertex_array_sqare);
		model_matrix =
			mat4::translate((NUM_MAP_ROW - 1) * map_length - map_not_using_length, 0, 0) *
			mat4::scale(map_not_using_length, 0.0f, NUM_MAP_COL * map_length - map_not_using_length);

		glUniform1i(glGetUniformLocation(program, "mode"), mode);
		glUniform1i(glGetUniformLocation(program, "color"), RED);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);


		// ********************** render text **********************
		float dpi_scale = cg_get_dpi_scale();
		render_text("Floor " + std::to_string(level), 20, 40, 0.8f, vec4(0.5f, 0.8f, 0.2f, 1.0f));
		
		render_text("level " + std::to_string(user.level), 20, window_size.y - 170, 0.5f, vec4(0.94f, 0.6f, 0.0f, 1.0f));
		render_text("Point " + std::to_string(user.point), 20, window_size.y - 140, 0.5f, vec4(0.94f, 0.6f, 0.0f, 1.0f));
		render_text("Exp " + std::to_string(user.exp) + " / " + std::to_string(user.need_exp), 20, window_size.y -110, 0.5f, vec4(0.5f, 0.8f, 0.2f, 1.0f));
		render_text("Hp " + std::to_string(user.hp) + " / " + std::to_string(user.full_hp), 20, window_size.y - 80, 0.5f, vec4(1.0f, 0.0f, 0.0f, 1.0f));
		render_text("Attack " + std::to_string(user.attack), 20, window_size.y - 50, 0.5f, vec4(0.0f, 0.0f, 1.0f, 1.0f));
		render_text("Range " + std::to_string(user.slen), 20, window_size.y - 20, 0.5f, vec4(0.0f, 1.0f, 0.0f, 1.0f));
		
		render_text("X" + std::to_string(time_speed), window_size.x - 130, 50, 1.0f, vec4(1.0f, 1.0f, 1.0f, 1.0f));

		render_text("Potion " + std::to_string(user.potion), window_size.x - 130, window_size.y - 20, 0.5f, vec4(0.5f, 0.8f, 0.2f, 1.0f));

		// swap front and back buffers, and display to screen
		glfwSwapBuffers(window);
	}
}

void reshape( GLFWwindow* window, int width, int height )
{
	// set current viewport in pixels (win_x, win_y, win_width, win_height)
	// viewport: the window area that are affected by rendering 
	window_size = ivec2(width,height);
	glViewport( 0, 0, width, height );
}

void print_help()
{
	printf( "[help]\n" );
	printf( "- press ESC or 'q' to terminate the program\n" );
	printf( "- press F1 or 'h' to see help\n" );
	printf( "- press Home to reset camera\n" );
	printf( "- press 'd' to toggle between OBJ format and 3DS format\n" );
	printf( "\n" );
}

void keyboard( GLFWwindow* window, int key, int scancode, int action, int mods )
{
	if(action==GLFW_PRESS)
	{
		if (key == GLFW_KEY_ESCAPE || key == GLFW_KEY_Q)	glfwSetWindowShouldClose(window, GL_TRUE);
		else if (key == GLFW_KEY_H || key == GLFW_KEY_F1)
		{
			if (screen != 7)
			{
				screen_tmp = screen;
				screen = 7;
			}
		}
		else if (key == GLFW_KEY_HOME)					cam = camera();
		else if (key == GLFW_KEY_T)					show_texcoord = !show_texcoord;
		else if (key == GLFW_KEY_R)		game_reset();
		else if (key == GLFW_KEY_1)
		{
			if (user.point)
			{
				user.point--;
				user.full_hp += 90 + user.hp_level * 10;
				user.hp += 90 + user.hp_level * 10;
				user.hp_level++;
			}
		}
		else if (key == GLFW_KEY_2)
		{
			if (user.point)
			{
				user.point--;
				user.attack += user.attack_level + 4;
				user.attack_level++;
			}
		}
		else if (key == GLFW_KEY_3)
		{
			if (user.slen < 15)
			{
				if (user.slen < 3)
				{
					if (user.point >= 1)
					{
						user.slen += 1;
						user.point -= 1;
					}
				}
				else if (user.slen < 9)
				{
					if (user.point >= 2)
					{
						user.slen += 2;
						user.point -= 2;
					}
				}
				else
				{
					if (user.point >= 3)
					{
						user.slen += 3;
						user.point -= 3;
					}
				}
			}
		}
		// ***************************** use potion ***************************
		else if (key == GLFW_KEY_P)
		{
			if (user.potion)
			{
				user.potion--;
				int real_plus_hp = (int)((float)potion_plus_hp / 100.0f * user.full_hp);
				if (real_plus_hp + user.hp >= user.full_hp)
					user.hp = user.full_hp;
				else
					user.hp = user.hp + real_plus_hp;
			}
		}
		else if (key == GLFW_KEY_G)
		{
			if (turn_time > 0.1f)
			{
				time_speed *= 2;
				turn_time /= 2;
			}
		}
		else if (key == GLFW_KEY_V)
		{
			if (turn_time < 2.0f)
			{
				time_speed /= 2;
				turn_time *= 2;
			}
		}
		else if(key==GLFW_KEY_T)
		{
			
		}
		else if (key == GLFW_KEY_KP_ADD)
		{
		}
		else if (key == GLFW_KEY_KP_SUBTRACT || key == GLFW_KEY_MINUS)
		{
		}
		else if (key == GLFW_KEY_Z)
		{
			back = !back;
			front = false;
		}
		else if (key == GLFW_KEY_X)
		{
			front = !front;
			back = false;
		}
		else if (key == GLFW_KEY_7)
		{
			user.point += 30;
		}
		// ***************************** moving **********************************
		else if ((key == GLFW_KEY_RIGHT || key == GLFW_KEY_DOWN || key == GLFW_KEY_LEFT || key == GLFW_KEY_UP) && moving == false && attacking == false && screen == 4)
		{
			turn++;
			moving = true;
			moving_time = float(glfwGetTime());
			if (key == GLFW_KEY_RIGHT)		moving_dir = RIGHT;
			else if (key == GLFW_KEY_DOWN)	moving_dir = DOWN;
			else if (key == GLFW_KEY_LEFT)	moving_dir = LEFT;
			else if (key == GLFW_KEY_UP)	moving_dir = UP;

			int next_user_x = user.pos_x + px[moving_dir];
			int next_user_z = user.pos_z + pz[moving_dir];

			if (next_user_x == NUM_MAP_ROW - 3 && next_user_z == NUM_MAP_COL - 2)
			{
				if (level == 10)	screen = 2;

				next_level();
				return;
			}

			// boundary check
			if (((uint)(next_user_x) > NUM_MAP_ROW - 2) || next_user_x < 0)			user.next_x = user.pos_x;
			else if (((uint)(next_user_z) > NUM_MAP_COL - 1) || next_user_z < 0)		user.next_z = user.pos_z;
			else if (map[next_user_x][next_user_z] != POTION && map[next_user_x][next_user_z])
			{
				user.next_x = user.pos_x;
				user.next_z = user.pos_z;

				camera_position.next_x = user.pos_x * map_length;
				camera_position.next_z = user.pos_z * map_length + 2.2f;
			}
			else
			{
				if (map[next_user_x][next_user_z] == POTION)
				{
					for (uint i = 0; i < potion.size(); i++)
					{
						if (potion[i].pos_x == next_user_x && potion[i].pos_z == next_user_z)
						{
							potion.erase(potion.begin() + i);
							break;
						}
					}
					user.potion += 1;
				}

				user.next_x = next_user_x;
				user.next_z = next_user_z;

				camera_position.next_x = next_user_x * map_length;
				camera_position.next_z = next_user_z * map_length + 2.2f;
			}
														
			map[user.pos_x][user.pos_z] = 0;
			map[user.next_x][user.next_z] = 2;

			for (uint i = 0; i < slime.size(); i++)		slime_next_pos(i);

			if (turn % potion_generate_time == 0 && potion.size() < 4)		generate_potion();
			if (turn % slime_generate_time == 0)
			{
				int slime_level = (int)randf((float)(std::max(1,level-2)), level + 0.99999f);
				generate_slime(slime_level);
			}

			print_map();
		}
		// ******************************* attack *************************************
		else if ((key == GLFW_KEY_D || key == GLFW_KEY_S || key == GLFW_KEY_A || key == GLFW_KEY_W) && attacking == false && moving == false && screen == 4)
		{
			engine->play2D(mp3_sword, false);
			turn++;
			attacking = true;
			attack_time = float(glfwGetTime());
			if (key == GLFW_KEY_D)		attack_dir = RIGHT;
			else if (key == GLFW_KEY_S)	attack_dir = DOWN;
			else if (key == GLFW_KEY_A)	attack_dir = LEFT;
			else if (key == GLFW_KEY_W)	attack_dir = UP;

			int qx[10], qz[10], r = 0;
			uint i;
			for (i = 0; i < (uint)user.slen; i++)
			{
				int x = user.pos_x + user.range_x[attack_dir][i];
				int z = user.pos_z + user.range_z[attack_dir][i];
				if (x > (int)(NUM_MAP_ROW) || x < 0)	continue;
				if (z > (int)(NUM_MAP_COL) || z < 0)	continue;
				if (map[x][z])
				{
					qx[r] = x;
					qz[r] = z;
					r++;
				}
			}
			uint j;
			for (i = 0;i<(uint)(r); i++)
			{
				for (j = 0; j < slime.size(); j++)
				{
					if (slime[j].pos_x == qx[i] && slime[j].pos_z == qz[i])
					{
						slime[j].hp -= user.attack;
						slime[j].angry = 1;
					}
					else
					{
						continue;
					}

					if (slime[j].hp <= 0)
					{	
						//engine->drop();
						map[slime[j].pos_x][slime[j].pos_z] = 0;
						dead_slime D;
						D.pos_x = slime[j].pos_x;
						D.pos_z = slime[j].pos_z;
						D.color = slime[j].color;
						dead_slimes.push_back(D);
						slime.erase(slime.begin() + j);
						user.exp += slime[j].level * 5;

						if (user.exp >= user.need_exp)
						{
							while (user.exp >= user.need_exp)
							{
								user.exp -= user.need_exp;
								user.level++;
								user.need_exp = user.need_exp + (user.level / 5 + 1) * 3;
							}
							user.point++;
						}
					}
				}
			}

			for (i = 0; i < slime.size(); i++)		slime_next_pos(i);
			
			if (turn % potion_generate_time == 0 && potion.size() < 4)	generate_potion();
			if (turn % slime_generate_time == 0)
			{
				int slime_level = (int)randf((float)(std::max(1, level - 2)), level + 0.99999f);
				generate_slime(slime_level);
			}
		}
	}
}

void mouse( GLFWwindow* window, int button, int action, int mods )
{
	if (screen == 0 && button == GLFW_MOUSE_BUTTON_LEFT)
	{
		dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
		float x = (float)(pos.x) / (float)(window_size.x);
		float y = (float)(pos.y) / (float)(window_size.y);
		if (x >= 520.0f / 1280.0f && x <= 760.0f / 1280.0f)
		{
			if (y >= 600.0f / 720.0f && y <= 680.0f / 720.0f)
			{
				if (screen_next_time + 0.5f < float(glfwGetTime()))
				{
					screen_next_time = float(glfwGetTime());
					screen = 4;
				}
			}
		}

		game_reset();
	}
	else if (screen == 7 && button == GLFW_MOUSE_BUTTON_LEFT)
	{
		if (screen_next_time + 0.5f < float(glfwGetTime()))
		{
			screen_next_time = float(glfwGetTime());
			screen = screen_tmp;
		}
	}
	else if (screen == 1 && button == GLFW_MOUSE_BUTTON_LEFT)
	{
		dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
		float x = (float)(pos.x) / (float)(window_size.x);
		float y = (float)(pos.y) / (float)(window_size.y);
		if (x >= 520.0f / 1280.0f && x <= 760.0f / 1280.0f)
		{
			if (y >= 600.0f / 720.0f && y <= 680.0f / 720.0f)
			{
				if (screen_next_time + 0.5f < float(glfwGetTime()))
				{
					screen_next_time = float(glfwGetTime());
					screen = 0;
				}
			}
		}

		game_reset();
	}
	else if (screen == 2 && button == GLFW_MOUSE_BUTTON_LEFT)
	{
		dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
		float x = (float)(pos.x) / (float)(window_size.x);
		float y = (float)(pos.y) / (float)(window_size.y);
		if (x >= 340.0f / 1280.0f && x <= 540.0f / 1280.0f)
		{
			if (y >= 540.0f / 720.0f && y <= 600.0f / 720.0f)
			{
				if (screen_next_time + 0.5f < float(glfwGetTime()))
				{
					screen_next_time = float(glfwGetTime());
					screen = 0;
					game_reset();
				}
			}
		}
		else if (x >= 740.0f / 1280.0f && x <= 940.0f / 1280.0f)
		{
			if (y >= 540.0f / 720.0f && y <= 600.0f / 720.0f)
			{
				if (screen_next_time + 0.5f < float(glfwGetTime()))
				{
					screen_next_time = float(glfwGetTime());
					screen = 4;
				}
			}
		}
	}
	else if(button==GLFW_MOUSE_BUTTON_LEFT)
	{
		dvec2 pos; glfwGetCursorPos(window,&pos.x,&pos.y);
		vec2 npos = cursor_to_ndc( pos, window_size );
		if(action==GLFW_PRESS)			tb.begin( cam.view_matrix, npos );
		else if(action==GLFW_RELEASE)	tb.end();
	}
}

void motion( GLFWwindow* window, double x, double y )
{
	if(!tb.is_tracking()) return;
	vec2 npos = cursor_to_ndc( dvec2(x,y), window_size );
	cam.view_matrix = tb.update( npos );
}

std::vector<vertex> create_title_vertices(void)
{
	std::vector<vertex> v;
	v.push_back({ vec3(-1.0f, -1.0f, 0.0f), vec3(0, 0, 1) , vec2(0.0f, 0.0f) });
	v.push_back({ vec3(+1.0f, -1.0f, 0.0f), vec3(0, 0, 1) , vec2(1.0f, 0.0f) });
	v.push_back({ vec3(+1.0f, +1.0f, 0.0f), vec3(0, 0, 1) , vec2(1.0f, 1.0f) });
	v.push_back({ vec3(-1.0f, +1.0f, 0.0f), vec3(0, 0, 1) , vec2(0.0f, 1.0f) });
	return v;
}

std::vector<vertex> create_sqare_vertices(void)
{
	std::vector<vertex> v;
	v.push_back({ vec3(0.0f, 0.0f, 0.0f), vec3(0, 1, 0) , vec2(0.0f, 0.0f) });
	v.push_back({ vec3(1.0f, 0.0f, 0.0f), vec3(0, 1, 0) , vec2(1.0f, 0.0f) });
	v.push_back({ vec3(1.0f, 0.0f, 1.0f), vec3(0, 1, 0) , vec2(1.0f, 1.0f) });
	v.push_back({ vec3(0.0f, 0.0f, 1.0f), vec3(0, 1, 0) , vec2(0.0f, 1.0f) });
	return v;
}

std::vector<vertex> create_slime_vertices(uint N)
{
	std::vector<vertex> v;
	for (uint k = 0; k <= N / 2; k++)
	{
		float radius = 0.45f;
		float theta = PI * k / float(N);
		float ct = cos(theta), st = sin(theta);
		for (uint j = 0; j <= 2 * N; j++)
		{
			float py = PI * j / float(N);
			float cp = cos(py), sp = sin(py);
			v.push_back({ vec3(st * sp * radius, ct * radius, st * cp * radius), vec3(st * sp,ct,st * cp) , vec2(py / (2 * PI),1 - theta / PI) });
		}
	}
	return v;
}

std::vector<vertex> create_slime_shadow_vertices(uint N)
{
	std::vector<vertex> v;
	float radius = 0.45f;
	float shadow_ratio = 1.2f;
	float theta = PI / N;
	v.push_back({ vec3(0,0,0), vec3(0,1,0), vec2(0.5f,0.5f) });
	for (uint k = 0; k <= N; k++)
	{
		v.push_back({ vec3(radius * sin(PI + k * theta) * shadow_ratio, 0.001f, radius * cos(PI + k * theta)), vec3(0,1,0), vec2(0.5f,0.5f) });
	}
	return v;
}

std::vector<vertex> create_map_vertices(uint a, uint b)
{
	map_not_using_length = 0.1f;
	map_real_length = 1.0f;
	map_length = map_not_using_length + map_real_length;
	std::vector<vertex> v;
	uint i, j;
	for (i = 0; i < a; i++)
	{
		for (j = 0; j < b; j++)
		{
			v.push_back({ vec3(float(i) * map_length, 0, float(j) * map_length),vec3(0,1,0),vec2(0,0) });
			v.push_back({ vec3(float(i) * map_length + map_real_length, 0, float(j) * map_length),vec3(0,1,0),vec2(0,0) });
			v.push_back({ vec3(float(i) * map_length, 0, float(j) * map_length + map_real_length),vec3(0,1,0),vec2(0,0) });
			v.push_back({ vec3(float(i) * map_length + map_real_length,0,float(j) * map_length + map_real_length),vec3(0,1,0),vec2(0,0) });
		}
	}
	return v;
}

void update_vertex_buffer_title(const std::vector<vertex>& vertices)
{
	static GLuint vertex_buffer = 0;	// ID holder for vertex buffer
	static GLuint index_buffer = 0;		// ID holder for index buffer

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// check exceptions
	if (vertices.empty()) { printf("[error] vertices is empty.\n"); return; }

	// create buffers
	std::vector<uint> indices;

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(0);
	indices.push_back(2);
	indices.push_back(3);

	// generation of vertex buffer: use vertices as it is
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array_title) glDeleteVertexArrays(1, &vertex_array_title);
	vertex_array_title = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array_title) { printf("%s(): failed to create title vertex array\n", __func__); return; }
}

void update_vertex_buffer_sqare(const std::vector<vertex>& vertices)
{
	static GLuint vertex_buffer = 0;	// ID holder for vertex buffer
	static GLuint index_buffer = 0;		// ID holder for index buffer

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// check exceptions
	if (vertices.empty()) { printf("[error] vertices is empty.\n"); return; }

	// create buffers
	std::vector<uint> indices;

	indices.push_back(0);
	indices.push_back(2);
	indices.push_back(1);
	indices.push_back(0);
	indices.push_back(3);
	indices.push_back(2);

	// generation of vertex buffer: use vertices as it is
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array_sqare) glDeleteVertexArrays(1, &vertex_array_sqare);
	vertex_array_sqare = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array_sqare) { printf("%s(): failed to create sqare vertex array\n", __func__); return; }
}

void update_vertex_buffer_slime(const std::vector<vertex>& vertices, uint N)
{
	static GLuint vertex_buffer = 0;	// ID holder for vertex buffer
	static GLuint index_buffer = 0;		// ID holder for index buffer

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// check exceptions
	if (vertices.empty()) { printf("[error] vertices is empty.\n"); return; }

	// create buffers
	std::vector<uint> indices;
	tri_num_slime = 0;

	for (uint k = 0; k < N / 2; k++)
	{
		for (uint j = 0; j < 2 * N; j++)
		{
			indices.push_back((k * (2 * N + 1)) + j);
			indices.push_back((k * (2 * N + 1)) + 2 * N + 1 + j);
			indices.push_back((k * (2 * N + 1)) + 2 * N + 2 + j);
			tri_num_slime++;
		}
	}
	for (uint k = 1; k < N / 2; k++)
	{
		for (uint j = 0; j < 2 * N; j++)
		{
			indices.push_back((k * (2 * N + 1)) + j);
			indices.push_back((k * (2 * N + 1)) + 2 * N + 2 + j);
			indices.push_back((k * (2 * N + 1)) + 1 + j);
			tri_num_slime++;
		}
	}

	// generation of vertex buffer: use vertices as it is
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array_slime) glDeleteVertexArrays(1, &vertex_array_slime);
	vertex_array_slime = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array_slime) { printf("%s(): failed to create silme vertex array\n", __func__); return; }
}

void update_vertex_buffer_slime_shadow(const std::vector<vertex>& vertices, uint N)
{
	static GLuint vertex_buffer = 0;	// ID holder for vertex buffer
	static GLuint index_buffer = 0;		// ID holder for index buffer

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// check exceptions
	if (vertices.empty()) { printf("[error] vertices is empty.\n"); return; }

	// create buffers
	std::vector<uint> indices;
	tri_num_slime_shadow = 0;

	for (uint k = 0; k < N; k++)
	{
		indices.push_back(0);
		indices.push_back(k + 1);
		indices.push_back(k + 2);
		tri_num_slime_shadow++;
	}

	// generation of vertex buffer: use vertices as it is
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array_slime_shadow) glDeleteVertexArrays(1, &vertex_array_slime_shadow);
	vertex_array_slime_shadow = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array_slime_shadow) { printf("%s(): failed to create silme shadow vertex array\n", __func__); return; }
}

void update_vertex_buffer_map(const std::vector<vertex>& vertices, uint a, uint b)
{
	static GLuint vertex_buffer = 0;	// ID holder for vertex buffer
	static GLuint index_buffer = 0;		// ID holder for index buffer

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// check exceptions
	if (vertices.empty()) { printf("[error] vertices is empty.\n"); return; }

	// create buffers
	std::vector<uint> indices;
	tri_num_map = 0;

	for (uint k = 0; k < a; k++)
	{
		for (uint j = 0; j < b; j++)
		{
			indices.push_back(4 * (b * k + j) + 0);
			indices.push_back(4 * (b * k + j) + 2);
			indices.push_back(4 * (b * k + j) + 1);
			tri_num_map++;
		}
	}
	for (uint k = 0; k < a; k++)
	{
		for (uint j = 0; j < b; j++)
		{
			indices.push_back(4 * (b * k + j) + 2);
			indices.push_back(4 * (b * k + j) + 3);
			indices.push_back(4 * (b * k + j) + 1);
			tri_num_map++;
		}
	}

	// generation of vertex buffer: use vertices as it is
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array_map) glDeleteVertexArrays(1, &vertex_array_map);
	vertex_array_map = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array_map) { printf("%s(): failed to create map vertex array\n", __func__); return; }
}

bool user_init()
{
	int i, j;
	for (i = 0; i < 100; i++)
	{
		for (j = 0; j < 100; j++)	map[i][j] = 0;
	}
	// log hotkeys
	print_help();

	// init GL states
	glClearColor( 39/255.0f, 40/255.0f, 34/255.0f, 1.0f );	// set clear color
	glEnable(GL_BLEND);
	glEnable( GL_CULL_FACE );								// turn on backface culling
	glEnable( GL_DEPTH_TEST );								// turn on depth tests
	glEnable( GL_TEXTURE_2D );
	glActiveTexture(GL_TEXTURE0);
	glActiveTexture(GL_TEXTURE1);
	glActiveTexture( GL_TEXTURE2 );
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	unit_slime_vertices = std::move(create_slime_vertices(NUM_TESS));
	unit_slime_shadow_vertices = std::move(create_slime_shadow_vertices(NUM_TESS));
	unit_map_vertices = std::move(create_map_vertices(NUM_MAP_ROW, NUM_MAP_COL));
	unit_sqare = std::move(create_sqare_vertices());
	unit_title = std::move(create_title_vertices());

	// create vertex buffer; called again when index buffering mode is toggled
	update_vertex_buffer_slime(unit_slime_vertices, NUM_TESS);
	update_vertex_buffer_slime_shadow(unit_slime_shadow_vertices, NUM_TESS);
	update_vertex_buffer_map(unit_map_vertices, NUM_MAP_ROW, NUM_MAP_COL);
	update_vertex_buffer_sqare(unit_sqare);
	update_vertex_buffer_title(unit_title);

	// load the mesh
	faceMesh = load_model(face_obj);
	if (faceMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	bodyMesh = load_model(body_obj);
	if (bodyMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	legMesh = load_model(leg_obj);
	if (legMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	stairMesh = load_model(mesh_stair);
	if (stairMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	potionMesh = load_model(mesh_potion);
	if (potionMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	exMesh = load_model(mesh_ex);
	if (exMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	swordMesh = load_model(sword_obj);
	if (swordMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	stoneMesh = load_model(stone_obj);
	if (stoneMesh == nullptr) { printf("Unable to load mesh\n"); return false; }
	woodMesh = load_model(wood_obj);
	if (woodMesh == nullptr) { printf("Unable to load mesh\n"); return false; }

	// texture
	TITLE = cg_create_texture(title_path, true); if (!TITLE) return false;
	FAIL = cg_create_texture(fail_path, true); if (!FAIL) return false;
	SUCCESS = cg_create_texture(success_path, true); if (!SUCCESS) return false;
	COMMENT = cg_create_texture(comment_path, true); if (!COMMENT) return false;
	particles.resize(10);
	printf("init end\n");
	if (!init_text()) return false;
	engine = irrklang::createIrrKlangDevice();
	if (!engine) return false;
	
	//add sound source from the sound file
	mp3_src = engine->addSoundSourceFromFile( mp3_path );
	mp3_sword = engine->addSoundSourceFromFile( mp3_path2 );
	//set default volume
	mp3_src->setDefaultVolume(0.2f);
	mp3_sword->setDefaultVolume(0.3f);
	//play the sound file
	engine->play2D( mp3_src, true );
	return true;
}

void user_finalize()
{
	slime.clear();
	delete_texture_cache();
	delete stairMesh;
	engine->drop();
}

int main( int argc, char* argv[] )
{
	// create window and initialize OpenGL extensions
	if(!(window = cg_create_window( window_name, window_size.x, window_size.y ))){ glfwTerminate(); return 1; }
	if(!cg_init_extensions( window )){ glfwTerminate(); return 1; }	// version and extensions

	// initializations and validations
	if(!(program=cg_create_program( vert_shader_path, frag_shader_path ))){ glfwTerminate(); return 1; }	// create and compile shaders/program
	if(!user_init()){ printf( "Failed to user_init()\n" ); glfwTerminate(); return 1; }					// user initialization

	// register event callbacks
	glfwSetWindowSizeCallback( window, reshape );	// callback for window resizing events
    glfwSetKeyCallback( window, keyboard );			// callback for keyboard events
	glfwSetMouseButtonCallback( window, mouse );	// callback for mouse click inputs
	glfwSetCursorPosCallback( window, motion );		// callback for mouse movement

	// enters rendering/event loop
	for( frame=0; !glfwWindowShouldClose(window); frame++ )
	{
		glfwPollEvents();	// polling and processing of events
		update();			// per-frame update
		render();			// per-frame render
	}
	
	// normal termination
	user_finalize();
	cg_destroy_window(window);

	return 0;
}

