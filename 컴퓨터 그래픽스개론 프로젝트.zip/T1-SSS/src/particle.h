#ifndef __PARTICLE_H__
#define __PARTICLE_H__
#pragma once

#include "cgmath.h"
#include "cgut.h"

inline float random_range( float min, float max ){ return mix( min, max, rand()/float(RAND_MAX) ); }
struct particle {
	vec3 pos;
	vec3 velocity;
	float life;
	float scale;
	float elapsed_time;
	float time_interval;

	particle() { reset(); }
	void reset();
	void update();
};
inline void particle::reset()
{
	pos = vec3(random_range(-1.0f, 1.0f), random_range(0.0f, 1.0f),random_range(-1.0f, 1.0f)) / 3.0f;
	pos = pos + vec3(0.5f, 0.5f, 0.5f);
	scale = random_range(0.08f, 0.3f);
	life = random_range(0.4f, 1.0f);
	velocity = vec3(random_range(-1.0f, 1.0f), random_range(-1.0f, 1.0f), random_range(-1.0f, 1.0f)) * 0.04f;
	elapsed_time = 0.0f;
	time_interval = random_range(20.0f, 60.0f);
}
inline void particle::update()
{
	const float dwTime = (float)glfwGetTime();
	elapsed_time += dwTime;

	if (elapsed_time > time_interval)
	{
		const float theta = random_range(0, 1.0f) * PI * 2.0f;
		constexpr float velocity_factor = 0.003f;
		velocity = vec3(cos(theta), sin(theta), 1.0f) * velocity_factor;

		elapsed_time = 0.0f;
	}

	pos += velocity;

	constexpr float life_factor = 0.001f;
	life -= life_factor * dwTime;
		
	// disappear
	if (life < 0.0f) 
	{ 
		constexpr float alpha_factor = 0.001f;
		scale -= alpha_factor * dwTime;
	}

	// dead
	if (scale < 0.0f) reset();
}

#endif